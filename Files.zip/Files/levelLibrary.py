# Developer: Dennis Dao
# Date: January 29th , 2019
# Attack on Robots - Level Library
# Version 1.0 Beta

# Imports pygame.
import pygame
import random

# Color constants.
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Platform Class
class Platform(pygame.sprite.Sprite):
    """ Platform the user can jump on """
    
    # Initiates initial variables.
    def __init__(self, platformNumber , width, height):
        """ Platform constructor. Assumes constructed with user passing in
            an array of 5 numbers like what's defined at the top of this code.
            """
        super().__init__()

        # This code changes the platform image depending on the level
        self.image = pygame.Surface([width, height])

        # Level 1
        if platformNumber == 1:
            self.image = pygame.image.load("levelOnePlatform.jpg").convert()
        # Level 2
        if platformNumber == 2:
            self.image = pygame.image.load("levelTwoPlatform.png").convert()
        # Level 3
        if platformNumber == 3:
            self.image = pygame.image.load("LevelThreePlatform.png").convert()
        # Level 4
        if platformNumber == 4:
            self.image = pygame.image.load("LevelFourPlatform.png").convert()
        self.rect = self.image.get_rect()
           
# Moving platform Class
class MovingPlatform(Platform):
    """ This is a fancier platform that can actually move. """

    # Variables for change in x and y 
    change_x = 0
    change_y = 0
    platform_speed = 0

    # Variables for boundaries. If boundaries are hit, the platform switches direction.
    boundary_top = 0
    boundary_bottom = 0
    boundary_left = 0
    boundary_right = 0
     
    player = None
 
    level = None

    # Update method for platforms
    def update(self):
        """ Move the platform.
            If the player is in the way, it will shove the player
            out of the way. This does NOT handle what happens if a
            platform shoves a player into another object. Make sure
            moving platforms have clearance to push the player around
            or add code to handle what happens if they don't. """
 
        # Move left/right
        self.rect.x += self.change_x
 
        # See if we hit the player
        hit = pygame.sprite.collide_rect(self, self.player)
        if hit:
            # We did hit the player. Shove the player around and
            # assume he/she won't hit anything else.
 
            # If we are moving right, set our right side
            # to the left side of the item we hit
            if self.change_x < 0:
                self.player.rect.right = self.rect.left
            else:
                # Otherwise if we are moving left, do the opposite.
                self.player.rect.left = self.rect.right
 
        # Move up/down
        self.rect.y += self.change_y
 
        # Check and see if we the player
        hit = pygame.sprite.collide_rect(self, self.player)
        if hit:
            # We did hit the player. Shove the player around and
            # assume he/she won't hit anything else.
 
            # Reset our position based on the top/bottom of the object.
            if self.change_y < 0:
                self.player.rect.bottom = self.rect.top
            else:
                self.player.rect.top = self.rect.bottom
 
        # Check the boundaries and see if we need to reverse direction.
        if self.rect.bottom > self.boundary_bottom:
            self.change_y = self.platform_speed
            self.change_y *= -1

        if self.rect.top < self.boundary_top:
            self.change_y = 1
            
        # Check the boundaries and see if we need to reverse direction.
        cur_pos = self.rect.x - self.level.world_shift
        if cur_pos < self.boundary_left or cur_pos > self.boundary_right:
            self.change_x *= -1

# Finish Platform Class 
class FinishPlatform(pygame.sprite.Sprite):

    def __init__(self, width, height):
        """ Platform constructor. Assumes constructed with user passing in
            an array of 5 numbers like what's defined at the top of this code.
            """
        super().__init__()

        # Initiates inital variables
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load("finishPlatform.png").convert()
        self.rect = self.image.get_rect()

# BackgroundObject Class 
class BackgroundObject(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

# LockedDoor Class
class LockedDoor(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        
# UnlockedDoor Class
class UnlockedDoor(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

# Switch Class
class Switch(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

# Obstacle Class
class Obstacle(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.rect = self.image.get_rect()

# Moving Obstacle Class
class MovingObstacle(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert_alpha()
        self.change_x = 0
        self.rect = self.image.get_rect()

    def update(self):
        self.rect.x += self.change_x

class FinalBoss(pygame.sprite.Sprite):
    def __init__(self, width, height, fileImage):

        # Initiates inital variables
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image = pygame.image.load(fileImage).convert()
        self.rect = self.image.get_rect()
        
# Level Class
class Level():
    """ This is a generic super-class used to define a level.
        Create a child class for each level with level-specific
        info. """
 
    def __init__(self, player):
        """ Constructor. Pass in a handle to player. Needed for when moving
            platforms collide with the player. """

        # Initiates inital variables
        self.platform_list = pygame.sprite.Group()
        self.backgroundObject_list = pygame.sprite.Group()
        self.obstacle_list = pygame.sprite.Group()
        self.moving_obstacle_list = pygame.sprite.Group()
        self.first_locked_door_list = pygame.sprite.Group()
        self.first_unlocked_door_list = pygame.sprite.Group()
        self.second_locked_door_list = pygame.sprite.Group()
        self.second_unlocked_door_list = pygame.sprite.Group()
        self.switch_one_list = pygame.sprite.Group()
        self.switch_two_list = pygame.sprite.Group()
        self.final_boss_list = pygame.sprite.Group()
        self.player = player

        # How far this world has been scrolled left/right
        self.world_shift = 0
 
    # Update everything on this level
    def update(self):
        """ Update everything in this level."""
        
        # Initiates inital variables
        self.platform_list.update()
        self.backgroundObject_list.update()
        self.obstacle_list.update()
        self.moving_obstacle_list.update()
        self.first_unlocked_door_list.update()
        self.first_locked_door_list.update()
        self.second_unlocked_door_list.update()
        self.second_locked_door_list.update()
        self.switch_one_list.update()
        self.switch_two_list.update()
        self.final_boss_list.update()

    # Method to draw everythingon the screen
    def draw(self, screen):
        """ Draw everything on this level. """
 
        # Draw all the sprite lists that we have
        self.platform_list.draw(screen)
        self.backgroundObject_list.draw(screen)
        self.obstacle_list.draw(screen)
        self.moving_obstacle_list.draw(screen)
        self.first_unlocked_door_list.draw(screen)
        self.first_locked_door_list.draw(screen)
        self.second_unlocked_door_list.draw(screen)
        self.second_locked_door_list.draw(screen)
        self.switch_one_list.draw(screen)
        self.switch_two_list.draw(screen)
        self.final_boss_list.draw(screen)

    # Method for shifting the world
    def shift_world(self, shift_x):
        """ When the user moves left/right and we need to scroll
        everything: """
 
        # Keep track of the shift amount
        self.world_shift += shift_x
 
        # Go through all the sprite lists and shift
        for platform in self.platform_list:
            platform.rect.x += shift_x

        # Moves the background objects with the world.
        for backgroundObject in self.backgroundObject_list:
            backgroundObject.rect.x += shift_x

        # Moves the obstacles with the world.
        for obstacle in self.obstacle_list:
            obstacle.rect.x += shift_x

        # Moves the moving obstacles with the world.
        for moving_obstacle in self.moving_obstacle_list:
            moving_obstacle.rect.x += shift_x

        # Moves the locked doors with the world.
        for first_locked_door in self.first_locked_door_list:
            first_locked_door.rect.x += shift_x

        # Moves the unlocked doors with the world.
        for first_unlocked_door in self.first_unlocked_door_list:
            first_unlocked_door.rect.x += shift_x

        # Moves the second locked door with the world.
        for second_locked_door in self.second_locked_door_list:
            second_locked_door.rect.x += shift_x

        # Moves the second unlocked door with the world.
        for second_unlocked_door in self.second_unlocked_door_list:
            second_unlocked_door.rect.x += shift_x

        # Moves the first switch with the world.
        for switch_one in self.switch_one_list:
            switch_one.rect.x += shift_x

        # Moves the second switch with the world.
        for switch_one in self.switch_two_list:
            switch_one.rect.x += shift_x

        for final_boss in self.final_boss_list:
            final_boss.rect.x += shift_x

# Create platforms for the level
class Level_01(Level):
    """ Definition for level 1. """
 
    def __init__(self, player):
        """ Create level 1. """
 
        # Call the parent constructor
        Level.__init__(self, player)

        # Sets the level limit.
        self.level_limit = -1700
 
        # Array with width, height, x, and y of platform
        level = [[210, 30, 0, 570], [210, 30, 200, 570], [210, 70, 500, 500],
                 [210, 70, 750, 400], [210, 70, 1000, 300], [210, 70, 1300, 200],
                 [210, 70, 1600, 400], [210, 70, 1900, 300],[210, 70, 2200, 200]]
    
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(1,platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player = self.player
            self.platform_list.add(block)

        # Adds the finish platform to the screen.
        finishLine = FinishPlatform(210, 70)
        finishLine.rect.x = 2500
        finishLine.rect.y = 400
        self.platform_list.add(finishLine)

        # Adds the sign to the screen.
        sign = BackgroundObject(84, 87, "Next Level Signpost.png")
        sign.rect.x = 0
        sign.rect.y = 485
        self.backgroundObject_list.add(sign)

        # Adds the sign to the screen.
        sign = BackgroundObject(84, 87, "Next Level Signpost.png")
        sign.rect.x = 2250
        sign.rect.y = 115
        self.backgroundObject_list.add(sign)

        tree = BackgroundObject(220, 324, "Plains Tree.png")
        tree.rect.x = 0
        tree.rect.y = 250
        self.backgroundObject_list.add(tree)

        tree = BackgroundObject(220, 324, "Plains Tree (2).png")
        tree.rect.x = 100
        tree.rect.y = 285
        self.backgroundObject_list.add(tree)

        tree = BackgroundObject(220, 324, "Plains Tree (2).png")
        tree.rect.x = 800
        tree.rect.y = 20
        self.backgroundObject_list.add(tree)

        tree = BackgroundObject(220, 324, "Plains Tree.png")
        tree.rect.x = 1900
        tree.rect.y = -10
        self.backgroundObject_list.add(tree)
                             
# Create platforms for the level
class Level_02(Level):
    """ Definition for level 2. """
 
    def __init__(self, player):
        """ Create level 2. """
 
        # Call the parent constructor
        Level.__init__(self, player)

        # Sets the level limit.
        self.level_limit = -4000
 
        # Array with width, height, x, and y of platform
        level = [[210, 80, -210, 570], [210, 80, 0, 570], [210, 80, 200, 570],
                 [210, 80, 500, 500], [210, 70, 750, 400], [210, 70, 2200, 200],
                 [210, 70, 2500, 200], [210, 70, 3500, 570], [210, 70, 3710, 570],
                 [210, 70, 3910, 570], [210, 70, 5010, 500], [210, 70, 5220, 500]]
    
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(2,platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player = self.player
            self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(2,70, 70)
        block.rect.x = 1000
        block.rect.y = 300
        block.boundary_top = 100
        block.boundary_bottom = 550
        block.change_y = 3
        block.platform_speed = 3
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform.
        block = MovingPlatform(2,70, 70)
        block.rect.x = 1300
        block.rect.y = 200
        block.boundary_top = 100
        block.boundary_bottom = 550
        block.change_y = -2
        block.platform_speed = 2
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(2, 70, 40)
        block.rect.x = 1600
        block.rect.y = 280
        block.boundary_left = 1550
        block.boundary_right = 1800
        block.change_x = 5
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(2, 70, 40)
        block.rect.x = 2801
        block.rect.y = 290
        block.boundary_left = 2800
        block.boundary_right = 3300
        block.change_x = 10
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(2, 70, 40)
        block.rect.x = 4250
        block.rect.y = 290
        block.boundary_left = 3900
        block.boundary_right = 4500
        block.boundary_top = 100
        block.boundary_bottom = 550
        block.change_y = 10
        block.platform_speed = 10
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(2, 70, 40)
        block.rect.x = 4500
        block.rect.y = 290
        block.boundary_left = 3900
        block.boundary_right = 4500
        block.boundary_top = 100
        block.boundary_bottom = 550
        block.change_y = -30
        block.platform_speed = 30
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Adds the finish platform to the screen.
        finishLine = FinishPlatform(210, 70)
        finishLine.rect.x = 4800
        finishLine.rect.y = 500
        self.platform_list.add(finishLine)

        # Adds the grass to the world
        for i in range(20, 200, 50):
            grass = BackgroundObject(102, 50, "Grass (2).png")
            grass.rect.x = 0 + i
            grass.rect.y = 520
            self.backgroundObject_list.add(grass)

        # Adds the signs to the world
        sign = BackgroundObject(84, 87, "Next Level Signpost.png")
        sign.rect.x = 0
        sign.rect.y = 485
        self.backgroundObject_list.add(sign)

        # Adds the trees to the world
        tree = BackgroundObject(313, 260, "Tree.png")
        tree.rect.x = 0
        tree.rect.y = 310
        self.backgroundObject_list.add(tree)

        # Adds the cactus to the world
        cactus = BackgroundObject(108, 111, "Cactus (1).png")
        cactus.rect.x = 250
        cactus.rect.y = 460
        self.backgroundObject_list.add(cactus)

        # Adds the bush to the world
        bush = BackgroundObject(145, 88, "Bush (1).png")
        bush.rect.x = 500
        bush.rect.y = 415
        self.backgroundObject_list.add(bush)

        # Adds the cactus to the world
        cactus = BackgroundObject(108, 111, "Cactus (1).png")
        cactus.rect.x = 600
        cactus.rect.y = 390
        self.backgroundObject_list.add(cactus)

        # Adds the cactus to the world
        cactus = BackgroundObject(70, 45, "Cactus (2).png")
        cactus.rect.x = 800
        cactus.rect.y = 355
        self.backgroundObject_list.add(cactus)

        # Adds the cactus to the world
        cactus = BackgroundObject(86, 96, "Cactus (3).png")
        cactus.rect.x = 2300
        cactus.rect.y = 105
        self.backgroundObject_list.add(cactus)

        # Adds the gass to the world
        grass = BackgroundObject(102, 50, "Grass (1).png")
        grass.rect.x = 2300
        grass.rect.y = 150
        self.backgroundObject_list.add(grass)

        # Adds the gass to the world
        grass = BackgroundObject(102, 50, "Grass (1).png")
        grass.rect.x = 2600
        grass.rect.y = 150
        self.backgroundObject_list.add(grass)

        # Adds the tree to the world
        tree = BackgroundObject(313, 260, "Tree.png")
        tree.rect.x = 3600
        tree.rect.y = 310
        self.backgroundObject_list.add(tree)

        # Adds the stone to the world
        stone = BackgroundObject(124, 73, "Stone.png")
        stone.rect.x = 3600
        stone.rect.y = 500
        self.backgroundObject_list.add(stone)

        # Adds the sign to the world
        sign = BackgroundObject(84, 87, "Next Level Signpost.png")
        sign.rect.x = 4850
        sign.rect.y = 415
        self.backgroundObject_list.add(sign)

        # Adds the skull to the world
        skull = BackgroundObject(150, 51, "Skeleton.png")
        skull.rect.x = 5000
        skull.rect.y = 455
        self.backgroundObject_list.add(skull)

# Create platforms for the level
class Level_03(Level):
    """ Definition for level 3. """
    def __init__(self, player):
        """ Create level 3. """
        # Call the parent constructor
        Level.__init__(self, player)
 
        self.level_limit = -1200
 
        # Array with width, height, x, and y of platform
        level = [[210, 80, 0, 550], [210, 80, 200, 550], [210, 80, 410, 550],
                 [210, 80, 620, 550], [210, 80, 500, 425], [210, 80, 500, 295],
                 [210, 80, 500, 165], [210, 80, 245, 320], [210, 80, 245, 190],
                 [210, 80, 755, 320], [210, 80, 755, 190], [210, 80, 500, 35],
                 [210, 80, 830, 550], [210, 80, 1040, 550], [210, 80, 1250, 550],
                 [210, 80, 1460, 550], [210, 80, -800, 550], [210, 80, -1010, 550],
                 [210, 80, -1640, 550], [210, 80, -1640, 200], [210, 80, -1850, 200],
                 [210, 80, -2100, 200], [210, 80, -2100, 70], [210, 80, -2100, -60],
                 [210, 80, -2100, 550], [210, 80, -2850, 200], [210, 80, -3100, 200],
                 [210, 80, -3100, 70], [210, 80, -3100, -60], [210, 80, -2850, -30],
                 [210, 80, -2850, -160], [210, 80, -3310, -30], [210, 80, -3310, -160],
                 [210, 80, -3310, 200], [210, 80, -4550, 550], [210, 80, -4760, 550],
                 [210, 80, -4970, 550], [210, 80, -5180, 550], [210, 80, -5390, 550],
                 [210, 80, -5600, 550], [210, 80, -5810, 550], [210, 80, -6020, 550],
                 [210, 80, -6440, 550], [210, 80, -6650, 550]]
    
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(3,platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player = self.player
            self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(3, 70, 40)
        block.rect.x = -276
        block.rect.y = 550
        block.boundary_left = -550
        block.boundary_right = -250
        block.change_x = 5
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(3,70, 70)
        block.rect.x = -1300
        block.rect.y = 200
        block.boundary_top = 100
        block.boundary_bottom = 800
        block.change_y = -2
        block.platform_speed = 2
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        block = MovingPlatform(3,70, 70)
        block.rect.x = -2520
        block.rect.y = 200
        block.boundary_top = 100
        block.boundary_bottom = 700
        block.change_y = -3
        block.platform_speed = 3
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Add a custom moving platform
        finishLine = FinishPlatform(210, 70)
        finishLine.rect.x = 2000
        finishLine.rect.y = 550
        self.platform_list.add(finishLine)

        # Adds a barrel to the world.
        barrel = BackgroundObject(40, 53, "Barrel (1).png")
        barrel.rect.x = 80
        barrel.rect.y = 500
        barrel.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(barrel)

        # Adds a barrel to the world.
        barrel = BackgroundObject(40, 53, "Barrel (2).png")
        barrel.rect.x = -900
        barrel.rect.y = 500
        barrel.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(barrel)

        # Adds a barrel to the world.
        barrel = BackgroundObject(40, 53, "Barrel (2).png")
        barrel.rect.x = -1500
        barrel.rect.y = 500
        barrel.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(barrel)

        # Adds a barrel to the world.
        barrel = BackgroundObject(40, 53, "Barrel (1).png")
        barrel.rect.x = -1600
        barrel.rect.y = 150
        barrel.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(barrel)

        # Adds a box to the world
        box = BackgroundObject(40, 53, "Box.png")
        box.rect.x = 200
        box.rect.y = 515
        box.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(box)
        
        # Adds a sign to the world
        sign = BackgroundObject(84, 87, "Next Level Signpost.png")
        sign.rect.x = 35
        sign.rect.y = 465
        self.backgroundObject_list.add(sign)

        # Adds the acid to the screen
        for i in range(-7680, 2560, 256):
            acid = Obstacle(256, 183, "Acid (1).png")
            acid.rect.x = 0 + i
            acid.rect.y = 575
            acid.image.set_colorkey(WHITE)
            self.obstacle_list.add(acid)

        # Adds the wire to the screen
        for i in range(0, 661, 33):
            wire = BackgroundObject(33, 10, "Wire.png")
            wire.rect.x = -2135 - i
            wire.rect.y = 100
            wire.image.set_colorkey(WHITE)
            self.backgroundObject_list.add(wire)

        # Adds and extends the wire
        for i in range(0, 7001, 33):
            wire = BackgroundObject(33, 10, "Wire.png")
            wire.rect.x = 450 - i
            wire.rect.y = 450
            wire.image.set_colorkey(WHITE)
            self.backgroundObject_list.add(wire)

        # Adds a switch to the world
        switch = Switch(28, 100, "Switch (1).png")
        switch.rect.x = -1800
        switch.rect.y = 100
        switch.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(switch)

        # Adds a switch to the world
        switch = Switch(28, 100, "Switch (2).png")
        switch.rect.x = -1800
        switch.rect.y = 100
        switch.image.set_colorkey(WHITE)
        self.switch_one_list.add(switch)

        # Adds a door to the world
        doorFinalEnt = UnlockedDoor(84, 87, "DoorUnlocked.png")
        doorFinalEnt.rect.x = 440
        doorFinalEnt.rect.y = 450
        doorFinalEnt.image.set_colorkey(WHITE)
        self.second_unlocked_door_list.add(doorFinalEnt)

        # Adds a door to the world
        doorFinalEnt = LockedDoor(84, 87, "DoorLocked.png")
        doorFinalEnt.rect.x = 440
        doorFinalEnt.rect.y = 450
        doorFinalEnt.image.set_colorkey(WHITE)
        self.second_locked_door_list.add(doorFinalEnt)

        # Adds a door to the world
        doorFinalExit = UnlockedDoor(84, 87, "DoorUnlocked.png")
        doorFinalExit.rect.x = 755
        doorFinalExit.rect.y = 450
        doorFinalExit.image.set_colorkey(WHITE)
        self.first_unlocked_door_list.add(doorFinalExit)

        # Adds a door to the world
        door = LockedDoor(84, 87, "DoorLocked.png")
        door.rect.x = -2845
        door.rect.y = 100
        door.image.set_colorkey(WHITE)
        self.first_locked_door_list.add(door)

        # Adds a door to the world
        door = UnlockedDoor(84, 87, "DoorUnlocked.png")
        door.rect.x = -2845
        door.rect.y = 100
        door.image.set_colorkey(WHITE)
        self.first_unlocked_door_list.add(door)

        # Adds a door to the world
        door = UnlockedDoor(84, 87, "DoorUnlocked.png")
        door.rect.x = -3150
        door.rect.y = 100
        door.image.set_colorkey(WHITE)
        self.first_unlocked_door_list.add(door)

        # Moving platform
        block = MovingPlatform(3, 70, 40)
        block.rect.x = -3700
        block.rect.y = 200
        block.boundary_left = -4000
        block.boundary_right = -3600
        block.change_x = 3
        block.player = self.player
        block.level = self
        self.platform_list.add(block)
        
        # Moving platform
        block = MovingPlatform(3,70, 70)
        block.rect.x = -4250
        block.rect.y = 200
        block.boundary_top = 100
        block.boundary_bottom = 600
        block.change_y = -2
        block.platform_speed = 2
        block.player = self.player
        block.level = self
        self.platform_list.add(block)

        # Adds switch to the screen
        switch = Switch(28, 100, "Switch (1).png")
        switch.rect.x = -6550
        switch.rect.y = 450
        switch.image.set_colorkey(WHITE)
        self.backgroundObject_list.add(switch)

        # Adds switch to the screen
        switch = Switch(28, 100, "Switch (2).png")
        switch.rect.x = -6550
        switch.rect.y = 450
        switch.image.set_colorkey(WHITE)
        self.switch_two_list.add(switch)
        
# Create platforms for the level
class Level_04(Level):
    """ Definition for level 3. """
    def __init__(self, player):
        """ Create level 3. """
        # Call the parent constructor
        Level.__init__(self, player)
 
        self.level_limit = -1200
 
        # Array with width, height, x, and y of platform
        level = [[210, 80, -210, 550],
                 [210, 80, 0, 550],
                 [210, 80, 200, 550],
                 [210, 80, 410, 550],
                 [210, 80, 620, 550],
                 [210, 80, 730, 550],
                 [210, 80, -50, 420],
                 [210, 80, 670, 420],
                 [210, 80, 315, 300]]
    
        # Go through the array above and add platforms
        for platform in level:
            block = Platform(4,platform[0], platform[1])
            block.rect.x = platform[2]
            block.rect.y = platform[3]
            block.player = self.player
            self.platform_list.add(block)

        # Makes the missiles going left to right.
        for missile in range(20):
            leftMissile = MovingObstacle(120, 160, "Heat Seeking Nuke.png")
            leftMissile.rect.x = random.randrange(-6000, -1000)
            leftMissile.rect.y = random.randrange(100, 500)
            leftMissile.change_x = 5
            leftMissile.image.set_colorkey(WHITE)
            self.moving_obstacle_list.add(leftMissile)
        
        # Makes the missiles going right to left.
        for missile in range(20):
            rightMissile = MovingObstacle(120, 160, "Heat Seeking Nuke (R).png")
            rightMissile.rect.x = random.randrange(3500, 9000)
            rightMissile.rect.y = random.randrange(100, 500)
            rightMissile.change_x = -5
            rightMissile.image.set_colorkey(WHITE)
            self.moving_obstacle_list.add(rightMissile)

