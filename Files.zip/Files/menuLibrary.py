# Developer: Adrian Musselwhite
# Date: January 29th , 2019
# Attack on Robots - Menu Library
# Version 1.0 Beta

# This imports the pygame library
import pygame

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Set the height and width of the screen
size = [SCREEN_WIDTH, SCREEN_HEIGHT]
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Attack on Robots")

# Main menu
def menu():

    # Mouse position
    mouse = pygame.mouse.get_pos()

    # If the mouse moves ontop of the start button a new screen iamge is loaded
    if  30 < mouse [0] < 185 and 405 < mouse [1] < 482:
        startMenu = pygame.image.load("mainMenuStart.jpg").convert()
        screen.blit(startMenu, [0, 0])
    # If the mouse moves ontop of the instructions button a new screen iamge is loaded
    elif  230 < mouse [0] < 600 and 405 < mouse [1] < 482:
        instructionsMenu = pygame.image.load("mainMenuInstructions.jpg").convert()
        screen.blit(instructionsMenu, [0, 0])
    # If the mouse moves ontop of the quit button a new screen iamge is loaded
    elif  645 < mouse [0] < 770 and 405 < mouse [1] < 482:
        quitMenu = pygame.image.load("mainMenuQuit.jpg").convert()
        screen.blit(quitMenu, [0, 0])
    # If the mouse is not over any of the sections the main menu with no images is selected
    else:
        mainMenu = pygame.image.load("mainMenu.jpg").convert()
        screen.blit(mainMenu, [0, 0])

    # Updates the screen
    pygame.display.flip()

# Instructions menu
def instructions():

    # Mouse position
    mouse = pygame.mouse.get_pos()

    # Loads the instructions screen image
    instructionsScreen = pygame.image.load("instructionsScreen.jpg").convert()
    screen.blit(instructionsScreen, [0, 0])

    # If the mouse moves ontop of the back to main button a new screen iamge is loaded
    if 270 < mouse [0] < 530 and 500 < mouse [1] < 540:
        instructionsScreen = pygame.image.load("instructionsScreenBacktoMain.jpg").convert()
        screen.blit(instructionsScreen, [0, 0])

    # Upadtes the screen
    pygame.display.flip()

# Pause Screen
def pauseScreen():

    # Mouse position
    mouse = pygame.mouse.get_pos()

    # Loads the pause screen image
    pausescreen = pygame.image.load("pauseScreen.jpg").convert()
    screen.blit(pausescreen, [0, 0])

    # If the mouse moves ontop of the resume button a new screen iamge is loaded
    if 285 < mouse [0] < 520 and 180 < mouse [1] < 225:
        pausescreenresume = pygame.image.load("pauseScreenResume.jpg").convert()
        screen.blit(pausescreenresume, [0, 0])
    # If the mouse moves ontop of the back to main button a new screen iamge is loaded
    if 120 < mouse [0] < 680 and 335 < mouse [1] < 382:
        pausescreenbacktomain = pygame.image.load("pauseScreenBacktoMain.jpg").convert()
        screen.blit(pausescreenbacktomain, [0, 0])

    # Updates the screen
    pygame.display.flip()


# Character select screen
def characterSelect():

    # Mouse position
    mouse = pygame.mouse.get_pos()

    # Loads the pause screen image
    characterSelect = pygame.image.load("characterSelectScreen.jpg").convert()
    screen.blit(characterSelect, [0, 0])

    # If the mouse moves ontop of the athlete character a new image is loaded 
    if 85 < mouse [0] < 300 and 160 < mouse [1] < 395:
        pausescreenbacktomain = pygame.image.load("characterOneSelectScreen.jpg").convert()
        screen.blit(pausescreenbacktomain, [0, 0])   
    # If the mouse moves ontop of the wizard character a new image is loaded 
    if 480 < mouse [0] < 700 and 160 < mouse [1] < 395:
        pausescreenbacktomain = pygame.image.load("characterTwoSelectScreen.jpg").convert()
        screen.blit(pausescreenbacktomain, [0, 0])
  
    # Updates the screen
    pygame.display.flip()

# Win Screen
def winScreen():
    # Mouse position
    mouse = pygame.mouse.get_pos()

    # Loads the pause screen image
    winScreen = pygame.image.load("winScreen.jpg").convert()
    screen.blit(winScreen, [0, 0])

    # If the mouse moves ontop of the back to main button a new image is loaded
    if 242 < mouse [0] < 560 and 440 < mouse [1] < 478:
        winScreenBackToMain = pygame.image.load("winScreenBackToMain.jpg").convert()
        screen.blit(winScreenBackToMain, [0, 0])

    # Updates the screen
    pygame.display.flip()    

