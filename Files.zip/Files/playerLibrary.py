# Developer: Matthew Wojcik
# Date: January 29th , 2019
# Attack on Robots - Player Library
# Version 1.0 Beta

# Imports pygame.
import pygame
import random
from levelLibrary import *
from menuLibrary import *

# Color constants.
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Pygame init
pygame.init()

# Game sound variables
jump_sound = pygame.mixer.Sound('jump_sound.ogg')
death_sound = pygame.mixer.Sound('death_sound.ogg')
switch_sound = pygame.mixer.Sound('switch_sound.wav')
door_sound = pygame.mixer.Sound('door_sound.wav')
boom_sound = pygame.mixer.Sound('Explosion.ogg')

# Player Class
class Player(pygame.sprite.Sprite):
    """
    This class represents the bar at the bottom that the player controls.
    """            
    # -- Methods
    def __init__(self):
        """ Constructor function """
 
        # Call the parent's constructor
        super().__init__()
 
        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        width = 40
        height = 60

        self.characterNumber = 1

        # This code determines what character to use
        
        # Character 1
        if self.characterNumber == 1:
            self.image = pygame.image.load("Player 1.png").convert_alpha()

        # Character 2
        if self.characterNumber == 2:
            self.image = pygame.image.load("Player 3.png").convert_alpha()
 
        # Set a referance to the image rect.
        self.rect = self.image.get_rect()
 
        # Set speed vector of player
        self.change_x = 0
        self.change_y = 0

        # Set death counters of player.
        self.deathCounter = 0
        self.hitCounter = 7

        # Set level 4 variables.
        self.onLastLevel = False
        self.minutes = 0
        self.seconds = 0
        self.robotMade = 0
        self.robotsDestroyed = 0
        self.won = 0

        # Sets initial frame count for the fourth level.
        self.frame_count = 0

        # List of sprites we can bump against
        self.level = None
        self.first_switch_enabled = False
        self.second_switch_enabled = False

    # Method to update the player       
    def update(self):
        """ Move the player. """
        
        # Sets up the timer to survive for the fourth level.
        if self.onLastLevel == True:
            self.frame_rate = 60
            self.total_seconds = self.frame_count // self.frame_rate
            self.minutes = self.total_seconds // 60
            self.seconds = self.total_seconds % 60
            self.frame_count += 1
        
        # Gravity
        self.calc_grav()
 
        # Move left/right
        self.rect.x += self.change_x
 
        # See if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right
 
        # Move up/down
        self.rect.y += self.change_y
 
        # Check and see if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        for block in block_hit_list:
 
            # Reset our position based on the top/bottom of the object.
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom
 
            # Stop our vertical movement
            self.change_y = 0

            # Checks to see if a player is on a moving object. Moves the player with it
            if isinstance(block, MovingPlatform):
                self.rect.x += block.change_x

        # See if we hit anything
        switch_one_hit_list = pygame.sprite.spritecollide(self, self.level.switch_one_list, True)
        for switch_one in switch_one_hit_list:
            if self.first_switch_enabled == False:
                self.first_switch_enabled = True
                switch_sound.play()

        # Checks if player collides with switch two
        switch_two_hit_list = pygame.sprite.spritecollide(self, self.level.switch_two_list, True)
        for switch_two in switch_two_hit_list:
            if self.second_switch_enabled == False:
                self.second_switch_enabled = True
                switch_sound.play()

        # Unlocks the door if the switch is enabled         
        if self.first_switch_enabled == True:
            first_locked_door_hit_list = pygame.sprite.spritecollide(self, self.level.first_locked_door_list, True)
            for first_locked_door in first_locked_door_hit_list:
                # If we are moving right,
                # set our right side to the left side of the item we hit
                if self.change_x > 0:
                    self.rect.x += 500
                    door_sound.play()
                elif self.change_x < 0:
                    # Otherwise if we are moving left, do the opposite.
                    self.rect.x -= 500
                    door_sound.play()

        # Checks to see of the first door is locked and hit
        else:
            first_locked_door_hit_list = pygame.sprite.spritecollide(self, self.level.first_locked_door_list, False)
            for first_locked_door in first_locked_door_hit_list:
                    if self.change_x > 0:
                        self.rect.right = first_locked_door.rect.left
                        switch_sound.play()
                    elif self.change_x < 0:
                        self.rect.left = first_locked_door.rect.right
                        switch_sound.play()
                        
        # Checks to see of the first door is unlocked and hit
        first_unlocked_door_hit_list = pygame.sprite.spritecollide(self, self.level.first_unlocked_door_list, False)
        for first_unlocked_door in first_unlocked_door_hit_list:
            if self.change_x > 0:
                self.rect.x += 400
                door_sound.play()
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.x -= 400
                door_sound.play()

        # Checks to see if the second door is locked 
        if self.second_switch_enabled == True:
            second_locked_door_hit_list = pygame.sprite.spritecollide(self, self.level.second_locked_door_list, True)
            for second_locked_door in second_locked_door_hit_list:
                # If we are moving right,
                # set our right side to the left side of the item we hit
                if self.change_x > 0:
                    self.rect.x += 400
                    door_sound.play()
                elif self.change_x < 0:
                    # Otherwise if we are moving left, do the opposite.
                    self.rect.x -= 400
                    door_sound.play()
                        
        # Checks to see if the second door is locked
        else:
            second_locked_door_hit_list = pygame.sprite.spritecollide(self, self.level.second_locked_door_list, False)
            for second_locked_door in second_locked_door_hit_list:
                    if self.change_x > 0:
                        self.rect.right = second_locked_door.rect.left
                        switch_sound.play()
                    elif self.change_x < 0:
                        self.rect.left = second_locked_door.rect.right
                        switch_sound.play()

        # Checks to see if the second door is unlocked.
        second_unlocked_door_hit_list = pygame.sprite.spritecollide(self, self.level.second_unlocked_door_list, False)
        for second_unlocked_door in second_unlocked_door_hit_list:
            if self.change_x > 0:
                self.rect.x += 400
                door_sound.play()
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.x -= 100
                door_sound.play()

        # Checks to see if an obstacle is hit
        obstacle_hit_list = pygame.sprite.spritecollide(self, self.level.obstacle_list, False)
        for hit in obstacle_hit_list:
            # Checks if it was hit while the switch was enabled.
            if self.second_switch_enabled == True:
                # Checks if you were moving right or up.
                if self.change_x > 0 or self.change_y > 0:
                    self.deathCounter += 1
                    self.rect.x = -6000 + self.level.world_shift
                    self.rect.y = SCREEN_HEIGHT - self.rect.height -50
                    death_sound.play()
                # Checks if you were moving left or down.
                elif self.change_x < 0 or self.change_y < 0:
                    self.deathCounter += 1
                    self.rect.x = -6000 + self.level.world_shift
                    self.rect.y = SCREEN_HEIGHT - self.rect.height -50
                    death_sound.play()
            else:
                # Checks if you were moving right or up.
                if self.change_x > 0 or self.change_y > 0:
                    self.deathCounter += 1
                    self.rect.x = 340 + self.level.world_shift
                    self.rect.y = SCREEN_HEIGHT - self.rect.height -50
                    death_sound.play()
                # Checks if you were moving left or down.
                elif self.change_x < 0 or self.change_y < 0:
                    self.deathCounter += 1
                    self.rect.x = 340 + self.level.world_shift
                    self.rect.y = SCREEN_HEIGHT - self.rect.height -50
                    death_sound.play()

        # Checks to see if a moving obstacle is hit
        moving_obstacle_hit_list = pygame.sprite.spritecollide(self, self.level.moving_obstacle_list, True)
        for hit in moving_obstacle_hit_list:
            # If hit while moving right or down.
            if self.change_x > 0 or self.change_y > 0:
                self.deathCounter += 1
                self.hitCounter -= 1
                self.rect.x = 340 + self.level.world_shift
                self.rect.y = -10
                death_sound.play()
            # If hit while not moving.
            elif self.change_x == 0 or self.change_y == 0:
                self.deathCounter += 1
                self.hitCounter -= 1
                self.rect.x = 340 + self.level.world_shift
                self.rect.y = -10
                death_sound.play()
            # If hit while moving left or up.
            elif self.change_x < 0 or self.change_y < 0:
                self.deathCounter += 1
                self.hitCounter -= 1
                self.rect.x = 340 + self.level.world_shift
                self.rect.y = -10
                death_sound.play()

        # If hit too many times by missiles, resets the counter for hits and time.
        if self.onLastLevel == True and self.hitCounter <= 0:
            self.hitCounter = 7
            self.total_seconds = 0
            self.seconds = 0
            self.minutes = 0
            self.frame_count = 0
            # Resets the missiles moving right.
            for missile in range(20):
                leftMissile = MovingObstacle(120, 160, "Heat Seeking Nuke.png")
                leftMissile.rect.x = random.randrange(-6000, -1000)
                leftMissile.rect.y = random.randrange(100, 500)
                leftMissile.change_x = 5
                leftMissile.image.set_colorkey(WHITE)
                self.level.moving_obstacle_list.add(leftMissile)

            # Resets the missiles moving left.                
            for missile in range(20):
                rightMissile = MovingObstacle(120, 160, "Heat Seeking Nuke (R).png")
                rightMissile.rect.x = random.randrange(3500, 9000)
                rightMissile.rect.y = random.randrange(100, 500)
                rightMissile.change_x = -5
                rightMissile.image.set_colorkey(WHITE)
                self.level.moving_obstacle_list.add(rightMissile)

        # Checks if the player is on the last level.
        if self.onLastLevel == True:
            # Checks if 30 seconds have passed and the robots haven't been made.
            if self.total_seconds == 30 and self.robotMade == 0:
                # Makes a robot.
                robot = FinalBoss(100, 104, "Robot 1 Large.png")
                robot.rect.x = self.level.world_shift
                robot.rect.y = 315
                robot.image.set_colorkey(WHITE)
                self.level.final_boss_list.add(robot)
                # Makes a robot.
                robot = FinalBoss(100, 100, "Robot 2 Large.png")
                robot.rect.x = self.level.world_shift + 300
                robot.rect.y = 450 
                robot.image.set_colorkey(WHITE)
                self.level.final_boss_list.add(robot)
                # Makes a robot.
                robot = FinalBoss(100, 112, "Robot 3 Large.png")
                robot.rect.x = self.level.world_shift + 800
                robot.rect.y = 315
                robot.image.set_colorkey(WHITE)
                self.level.final_boss_list.add(robot)

                # Adds 1 to robots made.
                self.robotMade += 1

        # Checks to see if the player runs into the boss.
        final_boss_hit_list = pygame.sprite.spritecollide(self, self.level.final_boss_list, True)
        for hit in final_boss_hit_list:
            # Checks if you were moving left.
            if self.change_x > 0:
                boom_sound.play()
                self.robotsDestroyed += 1
            # Checks if you were moving right. 
            elif self.change_x < 0:
                boom_sound.play()
                self.robotsDestroyed += 1
            # Checks if you weren't moving (robot spawned on top of the player)
            elif self.change_x == 0:
                boom_sound.play()
                self.robotsDestroyed += 1
            # Checks if you were moving down.
            elif self.change_y > 0:
                boom_sound.play()
                self.robotsDestroyed += 1

        # If all robots are destroyed, the player has won the game.
        if self.robotsDestroyed == 3:
            self.won = 1
            winScreen()
                
    # Gravity of character                
    def calc_grav(self):
        """ Calculate effect of gravity. """
        # If you are the wizard, you end up jumping higher.
        if self.characterNumber == 2:
            if self.change_y == 0:
                self.change_y = 1
            else:
                self.change_y += .25
                
        # If you are the athelete, you fall normal.        
        else:
            if self.change_y == 0:
                self.change_y = 1
            else:
                self.change_y += .35

    # Method for when a character jumps
    def jump(self):
        """ Called when user hits 'jump' button. """
        # Move down a bit and see if there is a platform below us.
        # Move down 2 pixels because it doesn't work well if we only move down 1
        # when working with a platform moving down.
        self.rect.y += 2

        # Checks to see if the player hit a platform.
        platform_hit_list = pygame.sprite.spritecollide(self, self.level.platform_list, False)
        self.rect.y -= 2
 
        # If it is ok to jump (platform was hit), set our speed upwards
        if len(platform_hit_list) > 0 or self.rect.bottom == SCREEN_HEIGHT:
            self.change_y = -10
            jump_sound.play()
 
    # Player-controlled movement:
    # Left
    def go_left(self):
        """ Called when the user hits the left arrow. """
        if self.characterNumber == 1:
            self.change_x = -10
        else:
            self.change_x = -6

    # Right
    def go_right(self):
        """ Called when the user hits the right arrow. """
        if self.characterNumber == 1:
            self.change_x = 10
        else:
            self.change_x = 6

    # Stop
    def stop(self):
        """ Called when the user lets off the keyboard. """
        self.change_x = 0
